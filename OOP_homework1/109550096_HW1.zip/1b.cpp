#include<iostream>
#include<cstdlib>
using namespace std;

//function
void matrix_trans(int** a, int** b,int m,int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			b[j][i] = a[i][j];
		}
	}
}

int main()
{
	int m, n;
	cout << "To create an mxn matrix" << endl;
	cout<<"m = ";
	cin >> m;
	cout << "n = ";
	cin >> n;

	int** a;
	a = new int* [m];
	for (int i = 0; i < m; i++)
	{
		*(a + i) = new int[n];
	}
	int** b;
	b = new int* [n];
	for (int i = 0; i < n; i++)
	{
		*(b + i) = new int[m];
	}
	cout << "Please input the number of the " << m << "x" << n << " matrix" << endl;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			int x;
			cin >> x;
			a[i][j] = x;
		}
	}
	cout << "Your matrix:" << endl;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << a[i][j] << " ";
		}
		cout << endl;
	}

	matrix_trans(a, b, m, n);

	cout << "Transpose matrix:" << endl;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			cout << b[i][j] << " ";
		}
		cout << endl;
	}

	return 0;
}