#include<iostream>
#include<algorithm>
using namespace std;

int randomnum(int seed);

int main()
{
	int a[100];
	cout << "Table = ";
	for (int i = 0; i < 100; i++)
	{
		a[i] = randomnum(i);
		cout << a[i] << " ";
	}
	cout << endl;
	int n;
	cout << "Which number do you want to count?" << endl;
	cin >> n;
	cout << "The occurences of the number = " << count(a, a + 100, n) << endl;

	return 0;
}

int randomnum(int seed)
{
	srand(seed);
	return rand() % 10;
}