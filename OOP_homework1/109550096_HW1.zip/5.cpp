#include<iostream>
using namespace std;

class poly
{
private:
	int a, b, c;
public:
	poly(int a,int b,int c):a(a),b(b),c(c)
	{}
	void add(poly ppoly)
	{
		cout << this->a + ppoly.a << "x^2 + " << this->b + ppoly.b << "x + " << this->c + ppoly.c << endl;
	}
};
int main()
{
	poly f1(1, 2, 3), f2(4, 5, 6);
	f1.add(f2);

	return 0;
}