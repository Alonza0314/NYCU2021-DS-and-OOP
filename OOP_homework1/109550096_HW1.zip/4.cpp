#include<iostream>
using namespace std;

class complex
{
private:
	int real_part;
	int i_part;
public:
	complex(int i, int j) :real_part(i), i_part(j)
	{}
	void show(int j)
	{
		if (j >= 0)
		{
			cout << "Your complex number is : " << this->real_part << "+" << this->i_part << "i" << endl;
		}
		else
		{
			cout << "Your complex number is : " << this->real_part << this->i_part << "i" << endl;
		}
	}
};

int main()
{
	int i, j;
	cout << "Please input the complex number for the type of a+bi." << endl;
	cout << "a = ";
	cin >> i;
	cout << "b = ";
	cin >> j;
	complex num(i, j);
	num.show(j);
	return 0;
}