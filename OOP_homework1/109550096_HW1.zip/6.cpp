#include<iostream>
using namespace std;

struct unit
{
	int n;
	unit* next;
};

class bag
{
public:
	unit* head, * last;
	bag()
	{
		head = new unit;
		head->next = NULL;
		last = head;
	}
	void initialize()
	{
		head = new unit;
		head->next = NULL;
		last = head;
	}
	void add_num(int n)
	{
		unit* temp = new unit;
		temp->n = n;
		temp->next = NULL;
		last->next = temp;
		last = temp;
		unit* current = head;
		cout << "The number:";
		while (current->next != NULL)
		{
			cout << current->next->n << " ";
			current = current->next;
		}
		cout << endl << endl;
	}
	void del_num_bag(int n)
	{
		unit* current = head;
		int flag = 1;
		int count = 0;
		if (current == NULL)
		{
			cout << "There is no number " << n << " in the bag!" << endl;
		}
		else
		{
			while (current->next != NULL)
			{
				if (current->next->n == n)
				{
					flag = 0;
					unit* temp = current->next;
					current->next = temp->next;
					delete(temp);
					count++;
					cout << "The bag with delete " << count << " of number " << n << ":";
					unit* temptemp = head;
					while (temptemp->next!= NULL)
					{
						cout << temptemp->next->n << " ";
						temptemp = temptemp->next;
					}
					cout << endl;
				}
				else
				{
					current = current->next;
				}
			}
			if (flag == 1)
			{
				cout << "No number " << n << " int the bag." << endl;
			}
		}
		cout << endl;
	}
};

class queue :public bag
{
public:
	queue()
	{
		this->head = new unit;
		this->head->next = NULL;
		this->last = this->head;
	}
	void del_num_queue()
	{
		unit* temp = head;
		if (temp->next == NULL)
		{
			cout << "The queue has been empty!" << endl << endl;
		}
		else
		{
			cout << "Delete  num " << temp->next->n << " from the first place of this queue." << endl;
			head = temp->next;
			delete(temp);
			unit* current = head;
			cout << "The queue now has the number:";
			while (current->next != NULL)
			{
				cout << current->next->n << " ";
				current = current->next;
			}
			cout << endl << endl;
		}

	}
};

int main()
{
	int n;
	cout << "Make a bag, input 1. Make a queue, input 2." << endl;
	cin >> n;
	if (n == 1)
	{
		bag bag;
		int flag = 1;
		while (flag == 1)
		{
			int m;
			cout << "Add number, input 1.Delete number, input 2.Stop this bag, input 3." << endl;
			cin >> m;
			if (m == 1)
			{
				int o;
				cout << "Add number = ";
				cin >> o;
				bag.add_num(o);
			}
			else if (m == 2)
			{
				int p;
				cout << "Delete number = ";
				cin >> p;
				bag.del_num_bag(p);
			}
			else if (m == 3)
			{
				flag = 0;
			}
			else
			{
				cout << "Wrong choice!" << endl << endl;
			}
		}
	}
	else if (n == 2)
	{
		queue queue;
		int flagg = 1;
		while (flagg == 1)
		{
			int q;
			cout << "Add number, input 1.Delete number, input 2.If you want to stop, input 3." << endl;
			cin >> q;
			if (q == 1)
			{
				int r;
				cout << "Add number = ";
				cin >> r;
				queue.add_num(r);
			}
			else if (q == 2)
			{
				queue.del_num_queue();
			}
			else if (q == 3)
			{
				flagg = 0;
			}
			else
			{
				cout << "Wrong choice!" << endl << endl;
			}
		}
	}
	else
	{
		cout << "Wrong choice!" << endl;
	}

	return 0;
}