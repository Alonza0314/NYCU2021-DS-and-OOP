#include<iostream>
#include<stack>
#include<string>
using namespace std;
/*
input:
3
-+*ABCD
*+AB+CD
-+AB*CD

output:
AB*C+D-
AB+CD+*
AB+CD*-
*/
int prio(char op)
{
	switch (op)
	{
	case '*':case'/':
		return 2;
	case '+':case '-':
		return 1;
	default:
		return 0;
	}
}
void pre_to_po(char* input, char* output)
{
	stack<char> temp;
	int j = 0;
	int x = 0;
	for (int i = 0; input[i] != '\0'; i++)
	{
		if (prio(input[i]) != 0)
		{
			temp.push(input[i]);
		}
		else
		{
			if (x == 0 && prio(temp.top()) == 2)
			{
				output[j] = input[i];
				j++; i++;
				output[j] = input[i];
				j++;
				output[j] = temp.top();
				j++;
				temp.pop();
				x = 1;
			}
			else if (x == 1 && prio(temp.top()) == 2)
			{
				output[j] = input[i];
				j++;
				output[j] = temp.top();
				j++;
				temp.pop();
			}
			else if (x == 1 && prio(temp.top()) == 1)
			{
				output[j] = input[i];
				j++;
				output[j] = temp.top();
				j++;
				temp.pop();
			}
			else if (x == 0 && prio(temp.top()) == 1)
			{
				output[j] = input[i];
				j++; i++;
				output[j] = input[i];
				j++;
				output[j] = temp.top();
				j++;
				temp.pop();
			}
		}
	}
	while (!temp.empty())
	{
		output[j++] = temp.top();
		temp.pop();
	}
	output[j] = '\0';
}


int main()
{
	int n;
	cin >> n;
	char** input, ** output;
	input = new char* [n + 1];
	output = new char* [n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		*(input + i) = new char[10];
	}
	for (int i = 0; i < n + 1; i++)
	{
		*(output + i) = new char[10];
	}
	for (int i = 0; i < n + 1; i++)
	{
		if (i == 0)
		{
			cin.getline(input[i], 10);
		}
		else
		{
			cout << "Your input [" << i << "] :";
			cin.getline(input[i], 10);

		}
	}
	for (int i = 1; i < n + 1; i++)
	{
		pre_to_po(input[i], output[i]);
	}

	cout << endl;
	for (int i = 1; i < n + 1; i++)
	{
		cout << "Your output[" << i << "] : " << output[i] << endl;
	}

	return 0;
}